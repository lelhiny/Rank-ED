(function(){
  'use strict';
  var module = angular.module('app', ['onsen']);
  alert("here 1");
  module.controller('AppController', function($scope, $data) {
    $scope.doSomething = function() {
      setTimeout(function() {
        ons.notification.alert({ message: 'tapped' });
      }, 100);
    };
  });

  module.controller('DetailController', function($scope, $data) {
    $scope.item = $data.selectedItem;
  });

  module.controller('MasterController', function($scope, $data) {
    $scope.items = $data.items;
    alert("Inside mastercontroller");
    $scope.showDetail = function(index) {
	alert('Inside show Details');
      var selectedItem = $data.items[index];
      $data.selectedItem = selectedItem;
    //  $scope.navi.pushPage('detail.html', {title : selectedItem.title});
	  $scope.navi.pushPage('chart.html', {title : selectedItem.title});
    };
  });
   module.controller('ChartController', function($http) {
   alert("Inside chartControlleer");
   var result;
        $http.get("http://localhost:5984/ranked/_design/testNew/_view/find")
          	     .then(function(response) {
				         result = response.data;
						          alert(result.rows.length);
								  var tempArray =[];
             for (var d in result) {
			 if(result[d].key == "AUS")
			  tempArray.push(result[d].value);
			}
			alert(tempArray[0].value);
						 $('#container').highcharts({
        chart: {
            type: 'line'
        },
        title: {
            text: 'Monthly Average Temperature'
        },
        subtitle: {
            text: 'Source: WorldClimate.com'
        },
        xAxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yAxis: {
            title: {
                text: 'Temperature (�C)'
            }
        },
        plotOptions: {
		 

            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        series: [{
            name: 'AUS',
			
            data: {tempArray}
        }, {
            name: 'London',
            data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
        }]
    });
						 		    }, function(response) {

        alert( "Something went wrong");
		});


   /* $('#container').highcharts({

        chart: {
            type: 'line'
        },
        title: {
            text: 'Monthly Average Temperature'
        },
        subtitle: {
            text: 'Source: WorldClimate.com'
        },
        xAxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yAxis: {
            title: {
                text: 'Temperature (�C)'
            }
        },
        plotOptions: {
		 

            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        series: [{
            name: 'Tokyo',
            data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
        }, {
            name: 'London',
            data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
        }]
    });*/
	alert('end');

});
  module.factory('$data', function() {
    /*    var data = {};
       var deferred = $q.defer();
     $http.get("http://localhost:5984/ranked/_design/testNew/_view/find")
	     .then(function(response) {
		 //First function handles success
        data = response.data;
			//	alert(data.total_rows.value);
						alert(data.rows.length);


		    }, function(response) {
			        //Second function handles error
					//Second function handles error
        data = "Something went wrong";
		alert("wrong");
		});*/
		//alert(data.total_rows.value);
		//alert(data.rows.length);
		
      var data = {};
     
      data.items = [
          {
              title: 'Item 1 Title',
              label: '4h',
              desc: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
          },
          {
              title: 'Another Item Title',
              label: '6h',
              desc: 'Ut enim ad minim veniam.'
          },
          {
              title: 'Yet Another Item Title',
              label: '1day ago',
              desc: 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'
          },
          {
              title: 'Yet Another Item Title',
              label: '1day ago',
              desc: 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'
          }
      ];

      return data;
  });
})();

